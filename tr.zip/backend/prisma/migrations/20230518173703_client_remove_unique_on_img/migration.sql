-- DropIndex
DROP INDEX "Clients_img_key";
