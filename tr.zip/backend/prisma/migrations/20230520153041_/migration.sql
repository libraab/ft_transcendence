-- AlterTable
ALTER TABLE "rooms" ADD COLUMN     "name2" VARCHAR(50);
