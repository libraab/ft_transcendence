/*
  Warnings:

  - You are about to drop the column `name2` on the `rooms` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "rooms" DROP COLUMN "name2";
