export default interface User42Interface {
  id: number;
  login: string;
  image: {
    link: string;
  };
  cookie: string;
}
