export default interface IJWT {

    id : number,
    iat : number,
};