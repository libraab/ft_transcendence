export enum Role {
  Owner = 'owner',
  Admin = 'admin',
  Member = 'member',
  Kicked = 'kicked',
  Banned = 'banned',
  Pendant = 'pendant',
}
