import { Controller } from '@nestjs/common';

@Controller('game')
export class GameController {}
