export function load()
{
	return {
		val: process.env.SECRET_TEST_FRT,
	};
}

