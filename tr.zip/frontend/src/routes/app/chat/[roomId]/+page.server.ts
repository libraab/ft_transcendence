export function load({ params }) {
	return {
		roomId: params.roomId
	};
}