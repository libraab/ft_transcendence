-- AlterTable
ALTER TABLE "client_stats" ALTER COLUMN "title" DROP NOT NULL;
