-- AlterTable
ALTER TABLE "Clients" ADD COLUMN     "dfaVerified" BOOLEAN;
