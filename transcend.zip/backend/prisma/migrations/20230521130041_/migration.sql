-- AlterTable
ALTER TABLE "Clients" ADD COLUMN     "DfaSecret" TEXT;
