TO RUN 
---------------
1. Open Docker
2. Run `docker-compose up --build` in ft_transcendence directory
