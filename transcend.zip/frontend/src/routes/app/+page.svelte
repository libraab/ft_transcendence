<script>

</script>

<h3>Welcome to the best pong game ever existed</h3>
<p>In this website you can enjoy the best experience on playing the original pong and a custom pong.</p>
<p>With the new technology of this times we created for you a chat interface.</p>

<h4>Some tips to help you :</h4>
<h5>Dashboard</h5>
<p>This is the place where you can look at yourself and be proud of all games you did.
	Your stats are visible here and you can follow your win/loose ratio.
	You can relive your matches by looking on the scores. Green score means you win this time, red you loose.
	You can see who did you win and to whom did you loose.
</p>
<h6>Friend</h6>
<p>You will have a lot of friends with some patience.
	Here you can see who is connected and who is playing already.
	You can send invitation to play from here as well.
</p>
<h6>Game</h6>
<p>Here the fun begin! Click here to play a game with some random person and show your best talents and skills.
	Don't forget to try to activate the mode to anjoy another type of experience.
</p>
<h6>Chat</h6>
<p>Here you can talk, trash talk, create your rooms, be the king of a room to kick and ban members. Or be banned because you spam too much.
	Or just join some random public rooms and make some friends. Don't forget to challenge people from there.
</p>
<h6>Settings</h6>
<p>Do you know that you can change avatar and your name? Take a look to settings.
	Oh and you can make your account safer with Dfa.
</p>

<style>

</style>