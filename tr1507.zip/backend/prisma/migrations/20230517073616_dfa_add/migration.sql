/*
  Warnings:

  - Added the required column `Dfa` to the `Clients` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Clients" ADD COLUMN     "Dfa" BOOLEAN NOT NULL;
