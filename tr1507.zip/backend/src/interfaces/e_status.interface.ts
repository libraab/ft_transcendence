export enum e_status 
{
  Connected,
  InGame,
  Disconnected
}