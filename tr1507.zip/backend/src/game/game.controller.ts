import { Controller } from '@nestjs/common';
import { validateSync } from 'class-validator';
import { DatabaseService } from 'src/database/database.service';

export class gameHistoricDto
{
    client1Id: number;
    scoreClient1: number;
    client2Id: number;
    scoreClient2: number;
}

@Controller('game')
export class GameController {
    constructor(private db: DatabaseService){}

    async saveScore(client1Id: string, scoreClient1: string,
        client2Id: number, scoreClient2: number)
    {
        const gameHistoric = new gameHistoricDto();
        gameHistoric.client1Id = client1Id;
        gameHistoric.scoreClient1 = scoreClient1;
        gameHistoric.client2Id = client2Id;
        gameHistoric.scoreClient2 = scoreClient2;
        console.log("gameHistoric: ", gameHistoric.client1Id, gameHistoric.scoreClient1, gameHistoric.client2Id, gameHistoric.scoreClient2)

        const errors = await validateSync(gameHistoric);
        if (errors.length > 0)
        {
            console.log(errors);
            return;
        }
        // const gameHistoricRepository = this.db.connection.getRepository(gameHistoricDto);
        // const gameHistoricEntity = gameHistoricRepository.create(gameHistoric);
        // await gameHistoricRepository.save(gameHistoricEntity);
    }
}
