import { Module } from '@nestjs/common';
import { ChatController } from './chat.controller';
import { ChatGateway } from './chat.gateway';
import { DatabaseService } from 'src/database/database.service';
import { createRoomDto } from 'src/dashboard/dashboardDtos/createsTablesDtos';
import { UserConnectedService } from './user-connected-service.service';

@Module({
  controllers: [ChatController],
  providers: [
    ChatGateway,
    DatabaseService,
    createRoomDto,
    UserConnectedService,
  ],
})
export class ChatModule {}
