
export async function load( { params } )
{
    return {
        gameId: params.gameId
    }
}