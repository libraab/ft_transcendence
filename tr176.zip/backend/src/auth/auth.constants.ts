export const jwtConstants = {
    secret: 'I LOVE 42.', // pour cripter les infos
  };