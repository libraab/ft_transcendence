import { Injectable } from '@nestjs/common';

@Injectable()
export class DashboardService
{
	/*

	// => mettre dans data-base/service/data-base.ts

	getUserIdByCookie()

	addFl()
	blockUser()
	seekUser(name : string)

	----------------------------------------------------

	getUserPublicInfoById(id: number)

	getUserStatsById(id: number)

	getUserFriendsRelationsById(id: number)

	getUserBlockedRelationsById(id: number)

	getUserRoomsByUserId(id: number)

	updateUserPublicInfoById(id: number)
	
	updateUserRelationsById(id: number)

	updateUserRoomsById(id: number)

	*/
}
