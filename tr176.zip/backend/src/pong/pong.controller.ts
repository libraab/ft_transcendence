import { Controller } from '@nestjs/common';

@Controller('pong')
export class PongController {}
