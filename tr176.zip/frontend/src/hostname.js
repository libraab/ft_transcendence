const hostname = "localhost";
export { hostname };