import { io } from 'socket.io-client'
import { hostname } from './hostname'
import { get, writable } from 'svelte/store';

export const rooms = writable([]);

let socket = {chat: null, game: null};
let socketData;

export async function initializeSocket(data) {
  socketData = await data;
  socket.chat = io(hostname+':3000/chat', {path: '/chatsockets'});//, auth: {token: }});
  socket.chat.emit('whoAmI', socketData.id);

  socket.game = io(hostname+':3000/pong', {path: '/pongsockets'});//, auth: {token: }});
  reloadRooms();
  defineSocketEvents();
  defineGameSocketEvents();
//   await new Promise(r => setTimeout(r, 3000)); //TEST
//   socket.chat.disconnect();
}

export async function reloadRooms() {
	let loadedRooms = await fetchData();
	rooms.set(loadedRooms);
	connectToRooms();
}

export function getSocket() {
  return socket;
}


export let defineSocketEvents = () =>
{
	socket.chat.on('serverAlertToChat', newMessage);
	// socket.chat.on('clientRefreshRooms', reloadRooms);
}

export let deleteSocketEvents = () =>
{
	socket.chat.off('serverAlertToChat', newMessage);
}

export let defineGameSocketEvents = () =>
{
	socket.game.on('testSeverToClient', (data) => {
		console.log(data)
	});

	socket.game.on('mvtpad', (data) => {

	}
}
/*
export let deleteGameSocketEvents = () =>
{
	socket.chat.off('testSeverToClient');
}
*/
export let newMessage = (msg) =>
{
	let trythis = get(rooms);
	trythis = trythis.map((item) => 
	{
		if (item.roomId == msg.channel)
			return { ...item, newMsgCount: item.newMsgCount + 1 };
		return (item);
	});
	rooms.set(trythis);
}

let connectToRooms = () => {
	get(rooms).forEach(room => {
		socket.chat.emit('joinChannel', room.roomId);
	});
}

async function fetchData() {
	let data = socketData;
	let curr_rooms = get(rooms);
	try {
		const response = await fetch(`http://${hostname}:3000/chat/${data.id42}`);
		let tmp_rooms = await response.json();
		tmp_rooms.forEach((el) =>
		{
			if (curr_rooms.find((room) => (room.roomId == el.roomId)) == undefined)
				curr_rooms = [...curr_rooms, { ...el, newMsgCount: 0}];
		});
		return curr_rooms;
	}
	catch (error) {
		console.error(error);
	}
}

/*
explication de ce fichier :
ce fichier permet de créer un socket client (qui va communiquer avec le socket server) et de définir les events du socket client 
	(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
ce fichier permet aussi de créer un store (qui est un objet qui contient des données qui peuvent être modifiées et qui peuvent être écoutées)
ce fichier permet aussi de récupérer les rooms et de les ajouter dans le store rooms
ce fichier permet aussi de connecter le socket chat à toutes les rooms

ce fichier sera en lien avec les fichiers suivants :
	- App.svelte pour récupérer les données de l'utilisateur et pour initialiser les sockets (chat et game)
	- Chat.svelte pour définir les events du socket chat (qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- Game.svelte pour définir les events du socket game (qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- Room.svelte pour définir les events du socket chat (qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- RoomList.svelte pour définir les events du socket chat (qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)

ce fichier contient les éléments suivants :

	- on importe io de socket.io-client (qui est un module npm) qui permet de créer un socket client (qui va communiquer avec le socket server)
	- on importe hostname de ./hostname qui est un fichier qui contient l'adresse ip du serveur
	- on importe get et writable de svelte/store qui permettent de créer un store (qui est un objet qui contient des données qui peuvent être modifiées et qui peuvent être écoutées)
	- on exporte rooms qui est un writable store qui contient un tableau vide (qui va contenir les rooms) 
	- on exporte initializeSocket qui est une fonction async qui prend en paramètre data (qui est un promise) 
		et qui va initialiser les sockets (chat et game) et qui va appeler la fonction reloadRooms qui va récupérer les rooms 
		et les ajouter dans le store rooms et qui va appeler la fonction connectToRooms qui va connecter le socket chat à toutes les rooms
	- on exporte getSocket qui est une fonction qui retourne l'objet socket (qui contient les sockets chat et game) 
	- on exporte defineSocketEvents qui est une fonction qui va définir les events du socket chat 
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte deleteSocketEvents qui est une fonction qui va supprimer les events du socket chat 
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte defineGameSocketEvents qui est une fonction qui va définir les events du socket game
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte deleteGameSocketEvents qui est une fonction qui va supprimer les events du socket game
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte newMessage qui est une fonction qui va être appelée quand le socket server va envoyer un event 'serverAlertToChat'
		et qui va incrémenter le nombre de nouveaux messages dans la room correspondante dans le store rooms
	- on exporte connectToRooms qui est une fonction qui va connecter le socket chat à toutes les rooms
	- on exporte fetchData qui est une fonction async qui va récupérer les rooms et les ajouter dans le store rooms
		et qui va retourner les rooms récupérées
	
	- on définit l'objet socket qui contient les sockets chat et game (qui sont des objets qui vont communiquer avec le socket server)
	- on définit socketData qui va contenir les données de l'utilisateur (qui sont récupérées dans le fichier App.svelte) 
	- on définit socket.chat qui est un socket client qui va communiquer avec le socket server (qui est un socket server qui va communiquer avec le socket client)
	- on définit socket.game qui est un socket client qui va communiquer avec le socket server (qui est un socket server qui va communiquer avec le socket client)
	- on définit socket.chat qui est un socket client qui va communiquer avec le socket server (qui est un socket server qui va communiquer avec le socket client)
	- on définit socket.game qui est un socket client qui va communiquer avec le socket server (qui est un socket server qui va communiquer avec le socket client)

	- on définit socket.chat.on('serverAlertToChat', newMessage); qui va appeler la fonction newMessage quand le socket server va envoyer un event 'serverAlertToChat' 
	- on définit socket.chat.on('clientRefreshRooms', reloadRooms); qui va appeler la fonction reloadRooms quand le socket server va envoyer un event 'clientRefreshRooms'
	- on définit socket.game.on('testSeverToClient', (data) => {console.log(data)}); qui va afficher data quand le socket server va envoyer un event 'testSeverToClient'
	- on définit socket.game.on('mvtpad', (data) => {}); qui va appeler la fonction mvtpad quand le socket server va envoyer un event 'mvtpad'
	- on définit newMessage qui va incrémenter le nombre de nouveaux messages dans la room correspondante dans le store rooms
	- on définit connectToRooms qui va connecter le socket chat à toutes les rooms (qui sont dans le store rooms)
	- on définit fetchData qui va récupérer les rooms et les ajouter dans le store rooms
		et qui va retourner les rooms récupérées
	
	- on exporte rooms qui est un writable store qui contient un tableau vide (qui va contenir les rooms) 
	- on exporte initializeSocket qui est une fonction async qui prend en paramètre data (qui est un promise)
		et qui va initialiser les sockets (chat et game) et qui va appeler la fonction reloadRooms qui va récupérer les rooms
		et les ajouter dans le store rooms et qui va appeler la fonction connectToRooms qui va connecter le socket chat à toutes les rooms
	- on exporte getSocket qui est une fonction qui retourne l'objet socket (qui contient les sockets chat et game) 
	- on exporte defineSocketEvents qui est une fonction qui va définir les events du socket chat
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte deleteSocketEvents qui est une fonction qui va supprimer les events du socket chat
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte defineGameSocketEvents qui est une fonction qui va définir les events du socket game
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte deleteGameSocketEvents qui est une fonction qui va supprimer les events du socket game
		(qui sont des fonctions qui vont être appelées quand le socket server va envoyer un event)
	- on exporte newMessage qui est une fonction qui va être appelée quand le socket server va envoyer un event 'serverAlertToChat'
		et qui va incrémenter le nombre de nouveaux messages dans la room correspondante dans le store rooms
	- on exporte connectToRooms qui est une fonction qui va connecter le socket chat à toutes les rooms
	
	- on exporte fetchData qui est une fonction async qui va récupérer les rooms et les ajouter dans le store rooms 
		et qui va retourner les rooms récupérées
	- on définit l'objet socket qui contient les sockets chat et game (qui sont des objets qui vont communiquer avec le socket server)

	*/