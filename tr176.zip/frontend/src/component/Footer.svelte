<footer>
	<div class="bigup">Transcendental team42 - share like suscribe</div>
</footer>

<style>
	footer{
		text-align: center;
	}
	.bigup{
		color: #aaa;
		font-size: 14px;
		display: inline-block;
		padding: 10px;
		border-top: 1px solid #ddd;
	}
</style>
