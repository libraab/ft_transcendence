#!/bin/bash

HOST=0.0.0.0 npm start dev